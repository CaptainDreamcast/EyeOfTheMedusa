﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Die Elementvorlage "Leere Seite" ist unter http://go.microsoft.com/fwlink/?LinkId=234238 dokumentiert.

namespace App2
{
    /// <summary>
    /// Eine leere Seite, die eigenständig verwendet werden kann oder auf die innerhalb eines Rahmens navigiert werden kann.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        private Robo robot;
        public MainPage()
        {
            this.InitializeComponent();
            this.robot = new Robo(inner);


        }

        private void Canvas_KeyDown(object sender, KeyRoutedEventArgs e)
        {

            if (e.Key == Windows.System.VirtualKey.Right)
            {
            
            }
            else if (e.Key == Windows.System.VirtualKey.Left)
            {
                robot.goLeft();
            }
            else if (e.Key == Windows.System.VirtualKey.Up)
            {
               
            }
            else if (e.Key == Windows.System.VirtualKey.Down)
            {
                
            }
            else if (e.Key == Windows.System.VirtualKey.Space)
            {
             
            }
        }

        private void test(object sender, RoutedEventArgs e)
        {
            this.robot.goLeft();
        }
    }
}

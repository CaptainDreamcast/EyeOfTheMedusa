﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace App2
{
    class Robo
    {

        public float x { get; set; }
        public float y { get; set; }

        public float speed { get; set; }

        public Canvas existence { get; set; }

        public Robo(Canvas newExistence) {
            this.x = 0.0f;
            this.y = 0.0f;
            this.speed = 3;
            this.existence = newExistence;
        }

        public void goLeft() {
            this.x-=this.speed;
            Canvas.SetLeft(this.existence, this.x);
        }

        
    }
}
